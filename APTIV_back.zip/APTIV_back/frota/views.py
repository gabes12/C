from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt

from frota.models import Frota

@csrf_exempt
def index(request):
    if not request.user.is_authenticated:
        return JsonResponse({
            'status': 401,
            "message": "Para acessar este recurso você precisa estar autenticado"
        })

    user = request.user

    frota_data = Frota.objects.filter(user=user).values('user_id', 'user__username', 'frota').first()

    return JsonResponse({
        "status": 200,
        "data": frota_data,
    })