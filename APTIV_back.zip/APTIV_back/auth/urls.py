from django.urls import path

from . import views

urlpatterns = [
    path("login", views.doLogin),
    path("logout", views.doLogout)
]