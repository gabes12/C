from django.contrib.auth import authenticate, login, logout
from django.http import HttpResponse, JsonResponse
from django.views.decorators.csrf import csrf_exempt
import json

@csrf_exempt
def doLogin(request):
    if request.method == 'POST':
        data = json.loads(request.body)
        username = data['username']
        password = data['password']

        user = authenticate(username=username, password=password)

        if user is not None:
            try:
                login(request, user)
                return JsonResponse({
                    "status": 200,
                    "message": "Usuário logado!"
                })
            except Exception as e:
                return HttpResponse(f'Erro: {e}', status=401)
        else:
            return HttpResponse('Usuário incorreto!', status=401)
    else:
        return HttpResponse('Bad request!', status=400)
    
@csrf_exempt
def doLogout(request):
    logout(request)
    return JsonResponse({
        'message': "Usuário deslogado com sucesso!"
    })