from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt

from holerites.models import Holerite

@csrf_exempt
def index(request):
    if not request.user.is_authenticated:
        return JsonResponse({
            'status': 401,
            "message": "Para acessar este recurso você precisa estar autenticado"
        })

    user = request.user

    holerite_data = Holerite.objects.filter(user=user).values('user_id', 'user__username', 'holerites').first()

    return JsonResponse({
        "status": 200,
        "data": holerite_data,
    })