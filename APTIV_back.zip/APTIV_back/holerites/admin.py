from django.contrib import admin
from .models import Holerite

admin.site.register(Holerite)
