from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt

from saude.models import Saude

@csrf_exempt
def index(request):
    if not request.user.is_authenticated:
        return JsonResponse({
            'status': 401,
            "message": "Para acessar este recurso você precisa estar autenticado"
        })

    user = request.user

    saude_data = Saude.objects.filter(user=user).values('user_id', 'user__username', 'plano_de_saude').first()

    return JsonResponse({
        "status": 200,
        "data": saude_data,
    })