from django.contrib import admin
from .models import Farmacia

admin.site.register(Farmacia)
