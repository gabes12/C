from django.contrib import admin
from .models import Unidade

admin.site.register(Unidade)
