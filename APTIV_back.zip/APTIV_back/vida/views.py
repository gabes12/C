from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt

from vida.models import Seguro_Vida

@csrf_exempt
def index(request):
    if not request.user.is_authenticated:
        return JsonResponse({
            'status': 401,
            "message": "Para acessar este recurso você precisa estar autenticado"
        })

    user = request.user

    vida_data = Seguro_Vida.objects.filter(user=user).values('user_id', 'user__username', 'seguro_de_vida').first()

    return JsonResponse({
        "status": 200,
        "data": vida_data,
    })