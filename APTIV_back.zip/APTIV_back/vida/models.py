from django.db import models
from django.contrib.auth.models import User

class Seguro_Vida(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    seguro_de_vida = models.JSONField()

    def __str__(self):
        return self.user.username
