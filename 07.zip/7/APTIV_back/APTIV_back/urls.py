from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path('admin/', admin.site.urls),
    path('holerites/', include('holerites.urls')),
    path('beneficios/', include('beneficios.urls')),
    path('restaurantes/', include('restaurantes.urls')),
    path('frota/', include('frota.urls')),
    path('saude/', include('saude.urls')),
    path('farmacia/', include('farmacia.urls')),
    path('vida/', include('vida.urls')),
    path('uniodonto/', include('uniodonto.urls')),
    path('conduta/', include('conduta.urls')),
    path('unidade/', include('unidade.urls')),
    path('auth/', include('auth.urls'))
]
