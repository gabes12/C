from django.contrib import admin
from .models import Beneficio

admin.site.register(Beneficio)
