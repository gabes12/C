from django.contrib.auth import authenticate, login, logout
from django.http import HttpResponse, JsonResponse
from django.views.decorators.csrf import csrf_exempt
from rest_framework_simplejwt.tokens import RefreshToken
import json

@csrf_exempt
def doLogin(request):
    if request.method == 'POST':
        data = json.loads(request.body)
        username = data['username']
        password = data['password']

        user = authenticate(username=username, password=password)

        if user:
            try:
                login(request, user)
                refresh = RefreshToken.for_user(user)
                token = {
                    'refresh': str(refresh),
                    'access': str(refresh.access_token),
                }
                return JsonResponse({
                    "status": 200,
                    "message": "Usuário logado!",
                    "token": token
                }, status=200)
            except Exception as e:
                return JsonResponse({
                    "message": "Erro",
                }, status=400)
        else:
            return JsonResponse({
                    "message": "Credenciais invalidas!",
                }, status=400)
    else:
        return HttpResponse('Bad request!', status=400)
    
@csrf_exempt
def doLogout(request):
    logout(request)
    return JsonResponse({
        'message': "Usuário deslogado com sucesso!"
    })