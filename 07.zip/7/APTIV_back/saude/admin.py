from django.contrib import admin
from .models import Saude

admin.site.register(Saude)
