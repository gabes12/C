from django.contrib import admin
from .models import Frota

admin.site.register(Frota)
