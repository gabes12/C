from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from rest_framework_simplejwt.tokens import TokenError, RefreshToken
from restaurantes.models import Restaurante

@csrf_exempt
def index(request):
    authorization_header = request.headers.get('Authorization')
    if authorization_header and authorization_header.startswith('Bearer '):
        token = authorization_header.split(' ')[1]
    
        try:
            access_token = RefreshToken(token)
            user = access_token.payload['user_id']
            restaurante_data = Restaurante.objects.filter(user=user).values('user_id', 'user__username', 'restaurantes').first()
            return JsonResponse({
                "status": 200,
                "data": restaurante_data,
            }, status=200)
        except TokenError as e:
            return JsonResponse({
                'status': 401,
                'message': f'Token de autenticação inválido: {e}'
            }, status=401)
    else:
        return JsonResponse({
            'status': 401,
            'message': 'Token de autenticação ausente ou inválido'
        }, status=401)


