from django.contrib import admin
from .models import Restaurante

admin.site.register(Restaurante)
