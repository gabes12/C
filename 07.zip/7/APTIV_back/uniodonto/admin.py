from django.contrib import admin
from .models import Uniodonto

admin.site.register(Uniodonto)
