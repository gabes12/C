from django.contrib import admin
from .models import Seguro_Vida

admin.site.register(Seguro_Vida)
