from django.apps import AppConfig


class VidaConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'vida'
