import unittest
import requests
import unittest
import HtmlTestRunner

class TestAPI(unittest.TestCase):

    def test_login(self):
        res = requests.post('http://127.0.0.1:8000/auth/login', json={
            "username": 'gabrielcosta',
            "password": '12345678'
        })
        jsonResult = res.json()

        self.assertTrue(jsonResult["message"], 'Usuário logado!')
        self.assertEqual(res.status_code, 200)

    def test_fail_login(self):  
        res = requests.post('http://127.0.0.1:8000/auth/login', json={
            "username": 'ciclano',
            "password": 'beltrano'
        })

        jsonResult = res.json()

        self.assertEqual(jsonResult['message'], 'Credenciais invalidas!')
        self.assertEqual(res.status_code, 400)

    def test_logout(self):
        res = requests.get('http://127.0.0.1:8000/auth/logout')
        jsonResult = res.json()
        self.assertEqual(jsonResult['message'], 'Usuário deslogado com sucesso!')

    def test_logged_beneficios(self):
        res = requests.post('http://127.0.0.1:8000/auth/login', json={
            "username": 'gabrielcosta',
            "password": '12345678'
        })
        jsonResult = res.json()

        access_token = jsonResult["token"]["refresh"]
        access_token = str(access_token)

        benefitsRes = requests.get('http://127.0.0.1:8000/beneficios/', headers={
            'Authorization': 'Bearer ' + access_token
        })
        
        jsonBenefitsResult = benefitsRes.json()
        self.assertEqual(jsonBenefitsResult['message'], 'Acesso liberado!')
        self.assertEqual(res.status_code, 200)


    def test_whitout_logged_beneficios(self):
        res = requests.post('http://127.0.0.1:8000/auth/login', json={
            "username": 'ciclano',
            "password": 'beltrano'
        })
        jsonResult = res.json()

        if "token" in jsonResult:
            access_token = jsonResult["token"]["refresh"]
            access_token = str(access_token)

            benefitsRes = requests.get('http://127.0.0.1:8000/beneficios/', headers={
                'Authorization': 'Bearer ' + access_token
            })
        else:
            benefitsRes = requests.get('http://127.0.0.1:8000/beneficios/')

        jsonBenefitsResult = benefitsRes.json()
        self.assertEqual(jsonBenefitsResult['message'], 'Token de autenticação ausente ou inválido')
        self.assertEqual(jsonBenefitsResult['status'], 401)

        

if __name__ == '__main__':
    unittest.main(testRunner=HtmlTestRunner.HTMLTestRunner(output=r'D:\Faculdade\2023_2\Topicos_1\7\tests_relatorio'))
